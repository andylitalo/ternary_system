# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 17:44:10 2018

@author: Andy
"""

# import packages
import glob
import os
import VideoFunctions as VF
import matplotlib.pyplot as plt
import numpy as np
import Functions as Fun

# User Parameters
folder = '..\\' # folder containing videos
fileString = 'test_vid.mp4' # filestring of videos to analyze

# Cleanup existing windows
plt.close('all')
   
# Get file path
pathToFiles = os.path.join(folder,fileString)
# Create list of files to analyze
fileList = glob.glob(pathToFiles)
# Number of videos to consider
nVideos = len(fileList)

# Loop through all videos
for v in range(nVideos):
    # Parse the filename to get video info
    videoPath = fileList[v]
    # Create video "object" for manipulation
    vid = VF.get_video_object(videoPath)
    nFrames = int(vid.get(7)) # number of frames in video
    # Loop through all frames
    for f in range(nFrames):
        # Extract frame from video--frame is a matrix of pixel values
        frame = VF.extract_frame(vid, f, removeBanner=False)
        ############### DISPLAY FRAME #####################
        # Open new figure for new video; same for new frame
        plt.figure(v+1)
        # Clear previous frame
        plt.cla()
        # converts black-and-white image to RGB (still shows up black and white)
        frame = np.dstack((frame,frame,frame))
        # Display frame
        Fun.plt_show_image(frame)
        # Pause before showing next frame
        plt.pause(.001)
    
